// script.js

document.addEventListener("DOMContentLoaded", () => {
  setActiveNav();
  updateFooterYear();
  initPage();
});

/* ===== NAV + FOOTER ===== */

function setActiveNav() {
  const page = document.body.dataset.page;
  document.querySelectorAll("nav a").forEach((link) => {
    if (link.dataset.page === page) {
      link.classList.add("active");
    }
  });
}

function updateFooterYear() {
  const span = document.getElementById("footer-year");
  if (span) {
    span.textContent = new Date().getFullYear();
  }
}

/* ===== ROUTE: PER PAGINA ===== */

function initPage() {
  const page = document.body.dataset.page;

  switch (page) {
    case "home":
      initHome();
      break;
    case "vluchtinfo":
      initVluchtinfo();
      break;
    case "media":
      initMedia();
      break;
    case "games":
      initGames();
      break;
    case "team":
      initTeam();
      break;
    case "camera":
      initCamera();
      break;
    case "holodeck":
      initHolodeck();
      break;
    case "menu":
      initMenu();
      break;
    case "muziek-eboeken":
      initMuziekEboeken();
      break;
    case "schip":
      initSchip();
      break;
    case "wellness":
      initWellness();
      break;
    default:
      break;
  }
}

/* ===== HOME ===== */

function initHome() {
  const greetEl = document.getElementById("home-greeting");
  const clockEl = document.getElementById("home-clock");
  const progressEl = document.getElementById("home-progress");

  function updateGreeting() {
    if (!greetEl) return;
    const h = new Date().getHours();
    let text = "Welkom aan boord";
    if (h >= 5 && h < 12) text = "Goedemorgen astronaut";
    else if (h >= 12 && h < 18) text = "Goedemiddag astronaut";
    else text = "Goedenavond astronaut";
    greetEl.textContent = text;
  }

  function updateClock() {
    if (!clockEl) return;
    clockEl.textContent = new Date().toLocaleTimeString("nl-NL", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
  }

  let progress = 20;
  function updateProgress() {
    if (!progressEl) return;
    progress = Math.min(100, progress + 0.04);
    progressEl.style.width = progress + "%";
  }

  updateGreeting();
  updateClock();
  setInterval(updateClock, 1000);
  setInterval(updateGreeting, 5 * 60 * 1000);
  setInterval(updateProgress, 500);
}

/* ===== VLUCHTINFO ===== */

let flightSeconds = 3 * 60 * 60 + 14 * 60 + 26;
const routeSteps = [
  "Net buiten de baan van de aarde",
  "Zwaartekracht-slingshot langs de maan",
  "Halverwege naar Mars",
  "Dicht bij Mars' baan",
  "Naderen van Mars-orbit"
];

function initVluchtinfo() {
  const countdownEl = document.getElementById("flight-time-left");
  const speedEl = document.getElementById("flight-speed");
  const locationEl = document.getElementById("flight-location");
  const refreshBtn = document.getElementById("flight-refresh");

  if (countdownEl) {
    updateCountdown(countdownEl);
    setInterval(() => {
      flightSeconds = Math.max(0, flightSeconds - 1);
      updateCountdown(countdownEl);
    }, 1000);
  }

  if (speedEl) {
    setInterval(() => {
      const base = 28000;
      const variation = Math.floor(Math.random() * 800) - 400;
      speedEl.textContent =
        (base + variation).toLocaleString("nl-NL") + " km/u";
    }, 3000);
  }

  if (locationEl) {
    let index = 0;
    setInterval(() => {
      index = (index + 1) % routeSteps.length;
      locationEl.textContent = routeSteps[index];
    }, 10000);
  }

  if (refreshBtn && countdownEl) {
    refreshBtn.addEventListener("click", () => {
      flightSeconds = Math.max(0, flightSeconds - 60);
      updateCountdown(countdownEl);
    });
  }
}

function updateCountdown(el) {
  const h = String(Math.floor(flightSeconds / 3600)).padStart(2, "0");
  const m = String(Math.floor((flightSeconds % 3600) / 60)).padStart(2, "0");
  const s = String(flightSeconds % 60).padStart(2, "0");
  el.textContent = `${h}:${m}:${s}`;
}

/* ===== MEDIA ===== */

const mediaData = [
  { title: "Journey to Mars", type: "Film", genre: "scifi", length: "1u 45m" },
  { title: "Orbit Life – S1", type: "Serie", genre: "drama", length: "8 afl." },
  { title: "Stars for Kids", type: "Serie", genre: "kids", length: "12 afl." },
  {
    title: "Inside the Spaceship",
    type: "Docu",
    genre: "docu",
    length: "52 min"
  },
  { title: "Galaxy Battles", type: "Film", genre: "scifi", length: "2u 10m" }
];

function initMedia() {
  const list = document.getElementById("media-list");
  const select = document.getElementById("media-filter");

  if (!list) return;

  function render(genre = "all") {
    list.innerHTML = "";
    const items =
      genre === "all"
        ? mediaData
        : mediaData.filter((m) => m.genre === genre);

    items.forEach((item) => {
      const card = document.createElement("article");
      card.className = "card";
      card.innerHTML = `
        <h3>${item.title}</h3>
        <p>${item.type} • ${item.length}</p>
        <p>${labelGenre(item.genre)}</p>
        <button class="btn media-play">Afspelen</button>
      `;
      list.appendChild(card);
    });

    list.querySelectorAll(".media-play").forEach((btn, index) => {
      btn.addEventListener("click", () => {
        const item =
          genre === "all" ? mediaData[index] : mediaData.filter((m) => m.genre === genre)[index];
        alert(`"${item.title}" start op jouw scherm.`);
      });
    });
  }

  function labelGenre(g) {
    switch (g) {
      case "scifi":
        return "Sciencefiction";
      case "drama":
        return "Drama";
      case "kids":
        return "Kids";
      case "docu":
        return "Documentaire";
      default:
        return g;
    }
  }

  render();

  if (select) {
    select.addEventListener("change", () => render(select.value));
  }
}

/* ===== GAMES (quiz) ===== */

const quizQuestions = [
  {
    q: "Hoe lang duurt een gemiddelde vlucht naar Mars?",
    opt: ["7–9 maanden", "3 dagen", "2 jaar"],
    correct: 0
  },
  {
    q: "Wat heb je nodig om in de ruimte te ademen?",
    opt: ["Niks, alleen een helm", "Ruimtepak of capsule", "Alleen zuurstofmasker"],
    correct: 1
  },
  {
    q: "Hoe heet onze thuisplaneet?",
    opt: ["Mars", "Aarde", "Jupiter"],
    correct: 1
  }
];

function initGames() {
  const container = document.getElementById("quiz");
  const btnStart = document.getElementById("quiz-start");
  const result = document.getElementById("quiz-result");

  if (!container || !btnStart || !result) return;

  btnStart.addEventListener("click", () => {
    container.innerHTML = "";
    result.textContent = "";

    quizQuestions.forEach((q, i) => {
      const block = document.createElement("div");
      block.className = "quiz-question";
      block.innerHTML = `<p>${i + 1}. ${q.q}</p>`;
      q.opt.forEach((option, idx) => {
        const label = document.createElement("label");
        label.className = "quiz-option";
        label.innerHTML = `
          <input type="radio" name="q${i}" value="${idx}"> ${option}
        `;
        block.appendChild(label);
      });
      container.appendChild(block);
    });

    const checkBtn = document.createElement("button");
    checkBtn.textContent = "Controleer antwoorden";
    checkBtn.className = "btn";
    checkBtn.addEventListener("click", () => {
      let score = 0;
      quizQuestions.forEach((q, i) => {
        const chosen = container.querySelector(
          `input[name="q${i}"]:checked`
        );
        if (chosen && Number(chosen.value) === q.correct) score++;
      });
      result.textContent = `Je hebt ${score} van de ${quizQuestions.length} vragen goed.`;
    });
    container.appendChild(checkBtn);
  });
}

/* ===== TEAM ===== */

const teamMembers = [
  {
    name: "Robert",
    role: "UI & Interaction",
    info: "Maakt de schermopbouw en navigatie duidelijk en gebruiksvriendelijk."
  },
  {
    name: "Raman",
    role: "Development",
    info: "Bouwt de structuur van de app en koppelt de pagina's aan elkaar."
  },
  {
    name: "Jesaja",
    role: "Visual design",
    info: "Zorgt voor stijl, kleuren en een consistente look & feel."
  }
];

function initTeam() {
  const grid = document.getElementById("team-grid");
  if (!grid) return;

  teamMembers.forEach((m) => {
    const card = document.createElement("article");
    card.className = "card team-card";
    card.innerHTML = `
      <h3>${m.name}</h3>
      <div class="team-role">${m.role}</div>
      <p class="team-extra">${m.info}</p>
    `;
    grid.appendChild(card);
  });

  grid.querySelectorAll(".team-card").forEach((card) => {
    card.addEventListener("click", () => {
      const extra = card.querySelector(".team-extra");
      extra.style.display = extra.style.display === "block" ? "none" : "block";
    });
  });
}

/* ===== CAMERA ===== */

function initCamera() {
  const view = document.getElementById("camera-view");
  const insideBtn = document.getElementById("camera-inside");
  const outsideBtn = document.getElementById("camera-outside");

  if (!view) return;

  function setView(type) {
    if (type === "inside") {
      view.textContent = "Live feed: Interieur – passagiersdek en lounge.";
    } else {
      view.textContent = "Live feed: Exterieur – zicht op sterren en Mars-route.";
    }
  }

  setView("inside");

  if (insideBtn) insideBtn.addEventListener("click", () => setView("inside"));
  if (outsideBtn) outsideBtn.addEventListener("click", () => setView("outside"));
}

/* ===== HOLODECK ===== */

function initHolodeck() {
  const cards = document.querySelectorAll("[data-scenario]");
  const detail = document.getElementById("holodeck-detail");
  if (!cards.length || !detail) return;

  cards.forEach((card) => {
    card.addEventListener("click", () => {
      const name = card.dataset.scenario;
      detail.textContent = `Scenario "${name}" wordt voorbereid. Zet je VR-headset op en volg de instructies op het scherm.`;
    });
  });
}

/* ===== MENU ===== */

function initMenu() {
  const breakfast = document.getElementById("menu-breakfast");
  const lunch = document.getElementById("menu-lunch");
  const dinner = document.getElementById("menu-dinner");

  const hour = new Date().getHours();
  let active;
  if (hour < 11) active = breakfast;
  else if (hour < 17) active = lunch;
  else active = dinner;

  if (active) active.style.borderColor = "var(--accent)";
}

/* ===== MUZIEK / E-BOOKEN ===== */

function initMuziekEboeken() {
  const tabMusic = document.getElementById("tab-music");
  const tabBooks = document.getElementById("tab-books");
  const paneMusic = document.getElementById("pane-music");
  const paneBooks = document.getElementById("pane-books");

  if (!tabMusic || !tabBooks || !paneMusic || !paneBooks) return;

  function show(which) {
    if (which === "music") {
      paneMusic.style.display = "block";
      paneBooks.style.display = "none";
      tabMusic.classList.add("active");
      tabBooks.classList.remove("active");
    } else {
      paneMusic.style.display = "none";
      paneBooks.style.display = "block";
      tabMusic.classList.remove("active");
      tabBooks.classList.add("active");
    }
  }

  tabMusic.addEventListener("click", () => show("music"));
  tabBooks.addEventListener("click", () => show("books"));

  show("music");
}

/* ===== SCHIP ===== */

function initSchip() {
  const toggles = document.querySelectorAll(".deck-toggle");
  toggles.forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.dataset.target;
      const panel = document.getElementById(targetId);
      if (!panel) return;
      const visible = panel.style.display === "block";
      panel.style.display = visible ? "none" : "block";
    });
  });
}

/* ===== WELLNESS ===== */

function initWellness() {
  const list = document.querySelectorAll("[data-activity]");
  const detail = document.getElementById("wellness-detail");
  if (!list.length || !detail) return;

  list.forEach((item) => {
    item.addEventListener("click", () => {
      const name = item.dataset.activity;
      detail.textContent = `Je hebt "${name}" geselecteerd. Je reservering wordt aangemaakt. Meld je 5 minuten van tevoren bij de wellnessbalie.`;
    });
  });
}
